<?php namespace pineapple;

class Configuration
{
    private $moduleName;

    public function __construct($moduleName)
    {
        $this->moduleName = $moduleName;
    }

    public function load()
    {

    }

    public function save()
    {
        
    }
}
